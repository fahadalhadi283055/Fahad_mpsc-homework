from restaurant_system.products import Burger 

class Order:
    """Manages a single customer order, tracking items and calculating totals."""

    def __init__(self, order_id): # This is complete
        """
        Initializes a new order with a unique ID and an empty list of items.
        """
        self.order_id = order_id
        self.items = []
        print(f"Order {self.order_id} started.")

    def add_item(self, burger: Burger):
        """
        Adds an item (like a Burger object) to the order.
        """
        name = burger.get_name()
        price = burger.get_price()
        self.items.append({'name': name, 'price': price})
        print(f"\"{name}\" added to order.")

    def get_total(self) -> float:
        """Calculates the total cost of all items in the order."""
        return round(sum(item['price'] for item in self.items), 2)

    def details(self): # This is complete
        """
        Generates a multi-line string representing the order receipt.
        """

        print(f"\nOrder ID: {self.order_id}\n")

        if not self.items:
            print("\n(No items in this order)")
        else:
            for item in self.items:
                print(f"- {item['name']}: ${item['price']:.2f}")

        total = self.get_total()
        print(f"Total: ${total:.2f}")


